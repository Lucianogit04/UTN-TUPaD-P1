package tp8ecommerce;

public class MainEcommerce {
    public static void main(String[] args) {
        Cliente cliente = new Cliente("Ana");
        Pedido pedido = new Pedido();

        pedido.agregarProducto(new Producto("Teclado", 15000));
        pedido.agregarProducto(new Producto("Mouse", 8000));

        System.out.println("Total del pedido: $" + pedido.calcularTotal());
        cliente.notificar("Pedido creado con total $" + pedido.calcularTotal());
    }
}