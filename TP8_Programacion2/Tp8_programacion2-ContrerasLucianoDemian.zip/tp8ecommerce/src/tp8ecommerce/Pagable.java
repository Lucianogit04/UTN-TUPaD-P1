package tp8ecommerce;

public interface Pagable {
    double calcularTotal();
}