package tp8ecommerce;

public interface Pago {
    boolean procesarPago(double monto);
}
