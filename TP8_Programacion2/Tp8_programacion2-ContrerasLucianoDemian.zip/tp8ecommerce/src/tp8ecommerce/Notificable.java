package tp8ecommerce;

public interface Notificable {
    void notificar(String mensaje);
}
