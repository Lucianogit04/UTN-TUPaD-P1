package tp8excepciones;

public class TestEdad {
    public static void main(String[] args) {
        try {
            Persona p = new Persona("Luis", 121);
        } catch (EdadInvalidaException e) {
            System.out.println("Excepcion capturada: " + e.getMessage());
        }
    }
}