package bibliotecalibro;

public class Main {
    public static void main(String[] args) {
        Biblioteca biblio = new Biblioteca("Biblioteca UTN");

        Autor a1 = new Autor("A01", "Borges", "Argentina");
        Autor a2 = new Autor("A02", "Cortazar", "Argentina");
        Autor a3 = new Autor("A03", "Allende", "Chile");

        biblio.agregarLibro("L001", "Ficciones", 1944, a1);
        biblio.agregarLibro("L002", "Rayuela", 1963, a2);
        biblio.agregarLibro("L003", "La casa de los espiritus", 1982, a3);
        biblio.agregarLibro("L004", "El Aleph", 1949, a1);
        biblio.agregarLibro("L005", "Final del juego", 1956, a2);

        System.out.println("Listado completo:");
        biblio.listarLibros();

        System.out.println("\nBuscar por ISBN:");
        Libro buscado = biblio.buscarLibroPorIsbn("L002");
        if (buscado != null) buscado.mostrarInfo();

        System.out.println("\nLibros publicados en 1949:");
        for (Libro l : biblio.filtrarLibrosPorAnio(1949)) {
            l.mostrarInfo();
        }

        System.out.println("\nEliminar libro L003:");
        biblio.eliminarLibro("L003");
        biblio.listarLibros();

        System.out.println("\nCantidad total de libros: " + biblio.obtenerCantidadLibros());

        System.out.println("\nAutores disponibles:");
        biblio.mostrarAutoresDisponibles();
    }
}