package com.mycompany.categoriaproducto;

public class Main {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        inventario.agregarProducto(new Producto("P001", "Arroz", 1200, 50, CategoriaProducto.ALIMENTOS));
        inventario.agregarProducto(new Producto("P002", "Notebook", 250000, 10, CategoriaProducto.ELECTRONICA));
        inventario.agregarProducto(new Producto("P003", "Campera", 8000, 20, CategoriaProducto.ROPA));
        inventario.agregarProducto(new Producto("P004", "Silla", 3000, 15, CategoriaProducto.HOGAR));
        inventario.agregarProducto(new Producto("P005", "Auriculares", 1500, 25, CategoriaProducto.ELECTRONICA));

        System.out.println("Listado completo:");
        inventario.listarProductos();

        System.out.println("\nBuscar por ID:");
        Producto buscado = inventario.buscarProductoPorId("P003");
        if (buscado != null) buscado.mostrarInfo();

        System.out.println("\nFiltrar por categoria ELECTRONICA:");
        for (Producto p : inventario.filtrarPorCategoria(CategoriaProducto.ELECTRONICA)) {
            p.mostrarInfo();
        }

        System.out.println("\nTotal de stock: " + inventario.obtenerTotalStock());
        System.out.println("\nProducto con mayor stock:");
        inventario.obtenerProductoConMayorStock().mostrarInfo();

        System.out.println("\nProductos entre $1000 y $3000:");
        for (Producto p : inventario.filtrarProductosPorPrecio(1000, 3000)) {
            p.mostrarInfo();
        }

        System.out.println("\nCategorias disponibles:");
        inventario.mostrarCategoriasDisponibles();
    }
}