package buniversidad;

import java.util.ArrayList;

public class Universidad {
    private String nombre;
    private ArrayList<Profesor> profesores = new ArrayList<>();
    private ArrayList<Curso> cursos = new ArrayList<>();

    public Universidad(String nombre) {
        this.nombre = nombre;
    }

    public void agregarProfesor(Profesor p) {
        profesores.add(p);
    }
    
    public void mostrarNombre() {
    System.out.println("Nombre de la universidad: " + nombre);
}
    public void agregarCurso(Curso c) {
        cursos.add(c);
    }

    public Profesor buscarProfesorPorId(String id) {
        for (Profesor p : profesores) {
            if (p.getId().equals(id)) return p;
        }
        return null;
    }

    public Curso buscarCursoPorCodigo(String codigo) {
        for (Curso c : cursos) {
            if (c.getCodigo().equals(codigo)) return c;
        }
        return null;
    }

    public void asignarProfesorACurso(String codigoCurso, String idProfesor) {
        Curso curso = buscarCursoPorCodigo(codigoCurso);
        Profesor profesor = buscarProfesorPorId(idProfesor);
        if (curso != null && profesor != null) {
            curso.setProfesor(profesor);
        }
    }

    public void listarProfesores() {
        for (Profesor p : profesores) {
            p.mostrarInfo();
            p.listarCursos();
        }
    }

    public void listarCursos() {
        for (Curso c : cursos) {
            c.mostrarInfo();
        }
    }

    public void eliminarCurso(String codigo) {
        Curso curso = buscarCursoPorCodigo(codigo);
        if (curso != null) {
            Profesor prof = curso.getProfesor();
            if (prof != null) {
                prof.eliminarCurso(curso);
            }
            cursos.remove(curso);
        }
    }

    public void eliminarProfesor(String id) {
        Profesor prof = buscarProfesorPorId(id);
        if (prof != null) {
            for (Curso c : cursos) {
                if (c.getProfesor() == prof) {
                    c.setProfesor(null);
                }
            }
            profesores.remove(prof);
        }
    }

    public void mostrarReporteCursosPorProfesor() {
        for (Profesor p : profesores) {
            System.out.println(p.getNombre() + " dicta " + p.getCantidadCursos() + " curso(s).");
        }
        
    }
}