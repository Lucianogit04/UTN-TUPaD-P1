package buniversidad;

public class Main {
    public static void main(String[] args) {
        Universidad utn = new Universidad("UTN");

        Profesor p1 = new Profesor("P01", "Ana Torres", "Matematica");
        Profesor p2 = new Profesor("P02", "Luis Gomez", "Programacion");
        Profesor p3 = new Profesor("P03", "Maria Lopez", "Estadistica");

        Curso c1 = new Curso("C101", "Algebra");
        Curso c2 = new Curso("C102", "Java");
        Curso c3 = new Curso("C103", "Probabilidad");
        Curso c4 = new Curso("C104", "Base de Datos");
        Curso c5 = new Curso("C105", "Logica");

        utn.agregarProfesor(p1);
        utn.agregarProfesor(p2);
        utn.agregarProfesor(p3);

        utn.agregarCurso(c1);
        utn.agregarCurso(c2);
        utn.agregarCurso(c3);
        utn.agregarCurso(c4);
        utn.agregarCurso(c5);

        utn.asignarProfesorACurso("C101", "P01");
        utn.asignarProfesorACurso("C102", "P02");
        utn.asignarProfesorACurso("C103", "P03");
        utn.asignarProfesorACurso("C104", "P02");
        utn.asignarProfesorACurso("C105", "P01");

        System.out.println("Cursos con sus profesores:");
        utn.listarCursos();

        System.out.println("\nProfesores con sus cursos:");
        utn.listarProfesores();

        System.out.println("\nCambiar profesor de C105 a P03:");
        utn.asignarProfesorACurso("C105", "P03");

        System.out.println("\nEliminar curso C104:");
        utn.eliminarCurso("C104");

        System.out.println("\nEliminar profesor P02:");
        utn.eliminarProfesor("P02");

        System.out.println("\nReporte de cursos por profesor:");
        utn.mostrarReporteCursosPorProfesor();
    }
}