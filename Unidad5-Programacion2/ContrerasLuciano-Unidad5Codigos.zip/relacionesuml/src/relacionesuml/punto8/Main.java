package relacionesuml.punto8;

public class Main {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("Valeria Torres", "valeria.torres@email.com");
        Documento documento = new Documento("Contrato de Servicios", "Contenido legal...", "ABC123XYZ", "2025-10-16", usuario);

        System.out.println("Documento: " + documento.getTitulo());
        System.out.println("Firmado por: " + documento.getFirma().getUsuario().getNombre());
        System.out.println("Email: " + documento.getFirma().getUsuario().getEmail());
        System.out.println("Hash: " + documento.getFirma().getCodigoHash() + " - Fecha: " + documento.getFirma().getFecha());
    }
}