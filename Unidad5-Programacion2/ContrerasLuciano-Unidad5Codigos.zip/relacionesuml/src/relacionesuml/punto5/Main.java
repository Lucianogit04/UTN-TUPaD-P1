package relacionesuml;

public class Main {
    public static void main(String[] args) {
        Propietario propietario = new Propietario("Martín López", "44556677");
        Computadora computadora = new Computadora("HP", "SN123456", "Z690", "Intel");

        computadora.setPropietario(propietario);

        System.out.println("Propietario: " + propietario.getNombre());
        System.out.println("Computadora: " + computadora.getMarca() + " (Serie: " + computadora.getNumeroSerie() + ")");
        System.out.println("Placa Madre: " + computadora.getPlacaMadre().getModelo() + " - Chipset: " + computadora.getPlacaMadre().getChipset());
    }
}