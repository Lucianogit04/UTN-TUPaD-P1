package relacionesuml;

public class Main {
    public static void main(String[] args) {
        Banco banco = new Banco("Banco Nacion", "30-12345678-9");
        Cliente cliente = new Cliente("Lucia Portillo", "11223344");
        TarjetaDeCredito tarjeta = new TarjetaDeCredito("4567-8901-2345-6789", "12/28", banco);

        tarjeta.setCliente(cliente);

        System.out.println("Cliente: " + cliente.getNombre());
        System.out.println("Tarjeta: " + tarjeta.getNumero() + " (Vence: " + tarjeta.getFechaVencimiento() + ")");
        System.out.println("Banco: " + tarjeta.getBanco().getNombre() + " - CUIT: " + tarjeta.getBanco().getCuit());
    }
}