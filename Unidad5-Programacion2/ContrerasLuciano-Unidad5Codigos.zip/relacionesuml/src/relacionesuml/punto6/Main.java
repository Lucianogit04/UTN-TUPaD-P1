package relacionesuml.punto6;

public class Main {
    public static void main(String[] args) {
        Cliente cliente = new Cliente("Laura Mendez", "1133445566");
        Mesa mesa = new Mesa(5, 4);
        Reserva reserva = new Reserva("2025-10-20", "20:30", cliente, mesa);
        System.out.println("Reserva para: " + reserva.getCliente().getNombre());
        System.out.println("Fecha: " + reserva.getFecha() + " - Hora: " + reserva.getHora());
        System.out.println("Mesa: " + reserva.getMesa().getNumero() + " (Capacidad: " + reserva.getMesa().getCapacidad() + ")");
    }
}