package relacionesuml.punto11;

public class Reproductor {
    // Dependencia de uso: no guarda la canción como atributo
    public void reproducir(Cancion cancion) {
        System.out.println("Reproduciendo: " + cancion.getTitulo());
        System.out.println("Artista: " + cancion.getArtista().getNombre() + " (" + cancion.getArtista().getGenero() + ")");
    }
}