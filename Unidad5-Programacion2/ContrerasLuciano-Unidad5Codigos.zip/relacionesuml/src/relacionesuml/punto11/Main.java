package relacionesuml.punto11;

public class Main {
    public static void main(String[] args) {
        Artista artista = new Artista("Luis Alberto Spinetta", "Rock Nacional");
        Cancion cancion = new Cancion("Seguir viviendo sin tu amor", artista);
        Reproductor reproductor = new Reproductor();

        reproductor.reproducir(cancion);
    }
}