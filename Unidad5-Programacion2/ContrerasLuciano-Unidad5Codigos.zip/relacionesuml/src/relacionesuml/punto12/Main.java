package relacionesuml.punto12;

public class Main {
    public static void main(String[] args) {
        Contribuyente contribuyente = new Contribuyente("Romina Diaz", "20-33445566-7");
        Impuesto impuesto = new Impuesto(100000.00, contribuyente);
        Calculadora calculadora = new Calculadora();

        calculadora.calcular(impuesto);
    }
}