package relacionesuml.punto12;

public class Calculadora {
    // Dependencia de uso: no guarda el impuesto como atributo
    public void calcular(Impuesto impuesto) {
        double resultado = impuesto.getMonto() * 0.21; // Ejemplo: IVA 21%
        System.out.println("Contribuyente: " + impuesto.getContribuyente().getNombre());
        System.out.println("Monto original: $" + impuesto.getMonto());
        System.out.println("IVA calculado: $" + resultado);
    }
}