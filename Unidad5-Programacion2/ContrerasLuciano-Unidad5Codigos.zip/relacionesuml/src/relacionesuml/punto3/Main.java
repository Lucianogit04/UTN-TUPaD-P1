package relacionesuml;

public class Main {
    public static void main(String[] args) {
        Autor autor = new Autor("Julio Cortázar", "Argentina");
        Editorial editorial = new Editorial("Sudamericana", "Av. Santa Fe 1234");
        Libro libro = new Libro("Rayuela", "978-987-1234567", autor, editorial);

        System.out.println("Libro: " + libro.getTitulo());
        System.out.println("Autor: " + libro.getAutor().getNombre() + " (" + libro.getAutor().getNacionalidad() + ")");
        System.out.println("Editorial: " + libro.getEditorial().getNombre() + " - " + libro.getEditorial().getDireccion());
    }
}