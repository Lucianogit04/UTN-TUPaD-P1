package relacionesuml.punto13;

public class Main {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("Camila Suarez", "camila.suarez@email.com");
        GeneradorQR generador = new GeneradorQR();

        generador.generar("QR-2025-ABC123", usuario);
    }
}