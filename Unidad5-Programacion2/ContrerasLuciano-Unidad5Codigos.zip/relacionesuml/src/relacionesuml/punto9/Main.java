package relacionesuml.punto9;

public class Main {
    public static void main(String[] args) {
        Paciente paciente = new Paciente("Maria Gonzalez", "33445566");
        Profesional profesional = new Profesional("Dr. Juan Perez", "Cardiologia");
        CitaMedica cita = new CitaMedica("2025-11-03", "09:30", paciente, profesional);

        System.out.println("Paciente: " + cita.getPaciente().getNombre());
        System.out.println("Profesional: " + cita.getProfesional().getNombre() + " (" + cita.getProfesional().getEspecialidad() + ")");
        System.out.println("Fecha: " + cita.getFecha() + " - Hora: " + cita.getHora());
    }
}