package relacionesuml.punto10;

public class Main {
    public static void main(String[] args) {
        Titular titular = new Titular("Julian Castro", "22334455");
        CuentaBancaria cuenta = new CuentaBancaria("0001234567890009876543", 150000.75, "X9A7B3", "2025-10-15");

        cuenta.setTitular(titular);

        System.out.println("Titular: " + titular.getNombre() + " (DNI: " + titular.getDni() + ")");
        System.out.println("CBU: " + cuenta.getCbu() + " - Saldo: $" + cuenta.getSaldo());
        System.out.println("Clave: " + cuenta.getClave().getCodigo() + " (Ultima modificacion: " + cuenta.getClave().getUltimaModificacion() + ")");
    }
}