package relacionesuml.punto14;

public class EditorVideo {
    // Dependencia de creación: crea el objeto dentro del método
    public void exportar(String formato, Proyecto proyecto) {
        Render render = new Render(formato, proyecto);
        System.out.println("Proyecto exportado: " + render.getProyecto().getNombre());
        System.out.println("Duracion: " + render.getProyecto().getDuracionMin() + " minutos");
        System.out.println("Formato: " + render.getFormato());
    }
}