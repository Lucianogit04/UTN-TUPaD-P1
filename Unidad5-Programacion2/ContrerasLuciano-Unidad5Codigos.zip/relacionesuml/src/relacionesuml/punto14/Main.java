package relacionesuml.punto14;

public class Main {
    public static void main(String[] args) {
        Proyecto proyecto = new Proyecto("Cortometraje 'Luz y Sombra'", 12);
        EditorVideo editor = new EditorVideo();

        editor.exportar("MP4", proyecto);
    }
}