package relacionesuml;

public class Main {
    public static void main(String[] args) {
        Bateria bateria = new Bateria("Ion-Litio", 4000);
        Usuario usuario = new Usuario("Carlos Pérez", "987654321");
        Celular celular = new Celular("123456789012345", "Samsung", "Galaxy S22", bateria);

        celular.setUsuario(usuario);

        System.out.println("Usuario: " + usuario.getNombre());
        System.out.println("Celular: " + celular.getMarca() + " " + celular.getModelo());
        System.out.println("Batería: " + celular.getBateria().getModelo() + " (" + celular.getBateria().getCapacidad() + " mAh)");
    }
}