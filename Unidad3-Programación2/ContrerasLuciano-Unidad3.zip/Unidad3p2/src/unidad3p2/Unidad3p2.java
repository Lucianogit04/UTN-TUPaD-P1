package unidad3p2;

class Mascota {
    String nombre;
    String especie;
    int edad;

    public Mascota(String nombre, String especie, int edad) {
        this.nombre = nombre;
        this.especie = especie;
        this.edad = edad;
    }

    public void mostrarInfo() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Especie: " + especie);
        System.out.println("Edad: " + edad + " años");
    }

    public void cumplirAnios() {
        edad++;
        System.out.println(nombre + " ha cumplido años. Nueva edad: " + edad);
    }
}

public class Unidad3p2 {
    public static void main(String[] args) {
        Mascota m1 = new Mascota("Nina", "Conejo", 1);

        m1.mostrarInfo();
        m1.cumplirAnios();
        m1.mostrarInfo();
    }
}