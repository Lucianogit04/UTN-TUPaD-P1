package unidad3p4;

class Gallina {
    int idGallina;
    int edad;
    int huevosPuestos;

    public Gallina(int idGallina, int edad) {
        this.idGallina = idGallina;
        this.edad = edad;
        this.huevosPuestos = 0;
    }

    public void ponerHuevo() {
        huevosPuestos++;
        System.out.println("Gallina " + idGallina + " puso un huevo.");
    }

    public void envejecer() {
        edad++;
        System.out.println("Gallina " + idGallina + " envejeció. Nueva edad: " + edad);
    }

    public void mostrarEstado() {
        System.out.println("ID: " + idGallina);
        System.out.println("Edad: " + edad + " años");
        System.out.println("Huevos puestos: " + huevosPuestos);
    }
}

public class Unidad3p4 {
    public static void main(String[] args) {
        Gallina g1 = new Gallina(101, 2);
        Gallina g2 = new Gallina(102, 1);

        g1.ponerHuevo();
        g1.ponerHuevo();
        g1.envejecer();

        g2.ponerHuevo();
        g2.envejecer();
        g2.envejecer();

        g1.mostrarEstado();
        g2.mostrarEstado();
    }
}