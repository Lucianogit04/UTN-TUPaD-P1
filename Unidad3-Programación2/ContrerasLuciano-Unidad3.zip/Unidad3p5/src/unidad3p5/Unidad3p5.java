package unidad3p5;

class NaveEspacial {
    private String nombre;
    private int combustible;

    public NaveEspacial(String nombre, int combustibleInicial) {
        this.nombre = nombre;
        this.combustible = combustibleInicial;
    }

    public void despegar() {
        if (combustible >= 10) {
            combustible -= 10;
            System.out.println(nombre + " ha despegado. Combustible restante: " + combustible);
        } else {
            System.out.println("No hay suficiente combustible para despegar.");
        }
    }

    public void avanzar(int distancia) {
        int consumo = distancia * 2;
        if (combustible >= consumo) {
            combustible -= consumo;
            System.out.println(nombre + " ha avanzado " + distancia + " unidades. Combustible restante: " + combustible);
        } else {
            System.out.println("Combustible insuficiente para avanzar " + distancia + " unidades.");
        }
    }

    public void recargarCombustible(int cantidad) {
        if (cantidad > 0) {
            combustible += cantidad;
            System.out.println("Se han recargado " + cantidad + " unidades de combustible. Total: " + combustible);
        } else {
            System.out.println("Cantidad inválida para recargar.");
        }
    }

    public void mostrarEstado() {
        System.out.println("Nave: " + nombre);
        System.out.println("Combustible actual: " + combustible);
        System.out.println("---------------------------");
    }
}

public class Unidad3p5 {
    public static void main(String[] args) {
        NaveEspacial nave1 = new NaveEspacial("Andrómeda", 50);

        nave1.despegar();               // consume 10
        nave1.recargarCombustible(20);  // suma 20
        nave1.avanzar(15);              // consume 30
        nave1.mostrarEstado();          // muestra estado final
    }
}