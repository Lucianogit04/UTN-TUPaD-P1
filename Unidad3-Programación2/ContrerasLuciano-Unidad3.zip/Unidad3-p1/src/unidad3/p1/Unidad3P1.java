package unidad3.p1;

class Estudiante {
    String nombre;
    String apellido;
    String curso;
    double calificacion;

    public Estudiante(String nombre, String apellido, String curso, double calificacion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.curso = curso;
        this.calificacion = calificacion;
    }

    public void mostrarInfo() {
        System.out.println("Nombre completo: " + nombre + " " + apellido);
        System.out.println("Curso: " + curso);
        System.out.println("Calificación: " + calificacion);
    }

    public void subirCalificacion(double puntos) {
        calificacion += puntos;
        System.out.println("Calificación aumentada en " + puntos + " puntos.");
    }

    public void bajarCalificacion(double puntos) {
        calificacion -= puntos;
        System.out.println("Calificación reducida en " + puntos + " puntos.");
    }
}

public class Unidad3P1 {
    public static void main(String[] args) {
        Estudiante e1 = new Estudiante("Lucía", "Gómez", "Programación I", 7.5);

        e1.mostrarInfo();
        e1.subirCalificacion(1.0);
        e1.bajarCalificacion(0.5);
        e1.mostrarInfo();
    }
}