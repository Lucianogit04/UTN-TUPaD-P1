package unidad3p3;

class Libro {
    private String titulo;
    private String autor;
    private int añoPublicacion;

    public Libro(String titulo, String autor, int añoPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        setAñoPublicacion(añoPublicacion); // usa el setter para validar
    }

    // Getters
    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAñoPublicacion() {
        return añoPublicacion;
    }

    // Setter con validación
    public void setAñoPublicacion(int año) {
        if (año >= 1500 && año <= 2025) {
            this.añoPublicacion = año;
        } else {
            System.out.println("Año inválido. Debe estar entre 1500 y 2025.");
        }
    }

    public void mostrarInfo() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Año de publicación: " + añoPublicacion);
    }
}

public class Unidad3p3 {
    public static void main(String[] args) {
        Libro libro1 = new Libro("Fundamentos de Java", "Carlos Pérez", 2020);

        // Intento de modificar con año inválido
        libro1.setAñoPublicacion(1400); // no se actualiza
        // Intento válido
        libro1.setAñoPublicacion(2015); // se actualiza

        libro1.mostrarInfo();
    }
}
