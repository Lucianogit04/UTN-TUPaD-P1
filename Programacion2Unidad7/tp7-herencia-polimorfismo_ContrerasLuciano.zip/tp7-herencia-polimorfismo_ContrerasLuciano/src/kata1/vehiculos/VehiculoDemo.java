package kata1.vehiculos;

public class VehiculoDemo {
    public static void main(String[] args) {
        Auto auto = new Auto("Toyota", "Corolla", 4);
        auto.mostrarInfo(); // muestra información completa
    }
}