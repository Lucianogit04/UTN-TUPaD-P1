package kata3.empleados;

import java.util.ArrayList;
import java.util.List;

public class EmpleadoDemo {
    public static void main(String[] args) {
        List<Empleado> empleados = new ArrayList<>();
        empleados.add(new EmpleadoPlanta("Ana", 300000, 40000));
        empleados.add(new EmpleadoTemporal("Luis", 120, 1500));

        for (Empleado e : empleados) {
            double sueldo = e.calcularSueldo(); // polimórfico
            String tipo = (e instanceof EmpleadoPlanta) ? "Planta" :
                          (e instanceof EmpleadoTemporal) ? "Temporal" : "Desconocido";
            System.out.println(e.getNombre() + " (" + tipo + ") - Sueldo: " + sueldo);
        }
    }
}