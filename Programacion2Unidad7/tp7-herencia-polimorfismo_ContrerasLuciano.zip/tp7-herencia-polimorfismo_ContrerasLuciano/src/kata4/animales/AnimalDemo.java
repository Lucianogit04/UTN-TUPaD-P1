package kata4.animales;

import java.util.Arrays;
import java.util.List;

public class AnimalDemo {
    public static void main(String[] args) {
        List<Animal> animales = Arrays.asList(
            new Perro(),  // upcasting implícito a Animal
            new Gato(),
            new Vaca()
        );

        for (Animal a : animales) {
            a.hacerSonido(); // polimórfico: se resuelve según el tipo real
            a.describirAnimal();
        }

        // Downcasting seguro con instanceof para comportamiento específico
        Animal a1 = new Perro();
        if (a1 instanceof Perro p) {
            // aquí podrías llamar métodos específicos de Perro, si existieran
            p.hacerSonido();
        }
    }
}