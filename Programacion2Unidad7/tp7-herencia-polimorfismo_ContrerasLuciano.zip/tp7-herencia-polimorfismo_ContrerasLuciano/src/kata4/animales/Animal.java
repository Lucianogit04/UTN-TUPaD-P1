package kata4.animales;

public class Animal {
    public void hacerSonido() {
        System.out.println("Sonido genérico de animal.");
    }

    public void describirAnimal() {
        System.out.println("Soy un animal.");
    }
}