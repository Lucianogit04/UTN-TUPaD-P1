
package darresultado;

public class DarResultado {
    public static void main(String[] args) {
        int a = 5;
        int b = 2;
        int resultado = a / b;

        System.out.println("Resultado: " + resultado);
    }
    
}
