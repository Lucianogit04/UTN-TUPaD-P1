package com.mycompany.informacionpersonal;

import java.util.Scanner;

public class InformacionPersonal {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Ingresa tu nombre: ");
        String nombre = input.nextLine();

        System.out.print("Ingresa tu edad: ");
        int edad = Integer.parseInt(input.nextLine());

        System.out.print("Ingresa tu altura en metros (ej. 1.75): ");
        double altura = Double.parseDouble(input.nextLine());

        System.out.print("¿Eres estudiante? (true/false): ");
        boolean estudiante = Boolean.parseBoolean(input.nextLine());

        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad + " anios");
        System.out.println("Altura: " + altura + " metros");
        System.out.println("Estudiante: " + (estudiante ? "Si" : "No"));

        input.close();
    }
}
