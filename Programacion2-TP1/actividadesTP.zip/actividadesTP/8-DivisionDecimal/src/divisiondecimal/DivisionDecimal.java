package divisiondecimal;
import java.util.Scanner;

public class DivisionDecimal {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Ingrese primer numero: ");
        double num1 = input.nextDouble();

        System.out.print("Ingrese segundo numero: ");
        double num2 = input.nextDouble();

        double resultado = num1 / num2;
        System.out.println("Resultado decimal: " + resultado);
    }
}
