package com.mycompany.divisionentera;

import java.util.Scanner;

public class DivisionEntera {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Ingrese primer numero: ");
        int num1 = input.nextInt();
        System.out.println("Ingrese segundo numero: ");
        int num2 = input.nextInt();
        
        int resultado = num1 / num2;
        System.out.println("Resultado Division:" + resultado);
    }
}
