package com.mycompany.datopersonal;

public class DatoPersonal {
    public static void main(String[] args) {
       System.out.println("Nombre: JuanPerez\nEdad: 30 anios\nDireccion: \"Calle Falsa 123\"");
    }
}
