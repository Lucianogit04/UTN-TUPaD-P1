
package com.mycompany.misdatos;

public class MisDatos {

    public static void main(String[] args) {
        String nombre = "Luciano";
        int edad = 21;
        double altura = 1.68;
        boolean estudiante = true;

        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad + " anios");
        System.out.println("Altura: " + altura + " metros");
        System.out.println("Es estudiante?: " + estudiante);
    }
}

