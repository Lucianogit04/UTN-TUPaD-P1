package punto4;

import java.util.Scanner;

public class Punto4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el precio del producto: ");
        double precioOriginal = sc.nextDouble();

        System.out.print("Ingrese la categoria del producto A (10%), B (15%) o C (20%): ");
        char categoria = sc.next()
                           .trim()
                           .toUpperCase()
                           .charAt(0);

        double porcentajeDescuento;
        switch (categoria) {
            case 'A':
                porcentajeDescuento = 10;
                break;
            case 'B':
                porcentajeDescuento = 15;
                break;
            case 'C':
                porcentajeDescuento = 20;
                break;
            default:
                System.out.println("Categoría inválida. Use A, B o C.");
                sc.close();
                return;
        }

        double montoDescuento = precioOriginal * porcentajeDescuento / 100;
        double precioFinal = precioOriginal - montoDescuento;

        System.out.println("\n--- RESULTADOS ---");
        System.out.println("Precio original:       $" + precioOriginal);
        System.out.println("Descuento aplicado:    " + (int)porcentajeDescuento + "%");
        System.out.println("Monto de descuento:    $" + montoDescuento);
        System.out.println("Precio final:          $" + precioFinal);

        sc.close();
    }
}


