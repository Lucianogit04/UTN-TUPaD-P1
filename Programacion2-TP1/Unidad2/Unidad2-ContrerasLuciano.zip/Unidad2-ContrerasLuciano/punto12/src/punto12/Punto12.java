package punto12;

public class Punto12 {

    public static void main(String[] args) {
        double[] precios = {199.99, 299.95, 149.75, 89.99, 399.99};

        System.out.println("Precios originales:");
        for (double precio : precios) {
            System.out.println("Precio: $" + precio);
        }

        precios[1] = 299.5;
        precios[2] = 299.5;

        System.out.println("Precios modificados:");
        for (double precio : precios) {
            System.out.println("Precio: $" + precio);
        }
    }
}
