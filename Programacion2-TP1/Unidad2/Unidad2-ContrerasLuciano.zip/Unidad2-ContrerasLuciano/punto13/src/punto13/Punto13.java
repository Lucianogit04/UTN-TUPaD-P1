package punto13;

public class Punto13 {

    public static void main(String[] args) {
        // a. Declarar e inicializar el array
        double[] precios = {199.99, 299.99, 149.75, 399.0, 89.99, 199.99};

        // b. Mostrar precios originales con recursividad
        System.out.println("Precios originales:");
        imprimirRecursivo(precios, 0);

        // c. Modificar precios específicos
        precios[1] = 299.5;
        precios[2] = 299.5;

        // d. Mostrar precios modificados con recursividad
        System.out.println("Precios modificados:");
        imprimirRecursivo(precios, 0);
    }

    // Función recursiva para imprimir precios
    public static void imprimirRecursivo(double[] array, int indice) {
        if (indice < array.length) {
            System.out.println("Precio: $" + array[indice]);
            imprimirRecursivo(array, indice + 1);
        }
    }
}
