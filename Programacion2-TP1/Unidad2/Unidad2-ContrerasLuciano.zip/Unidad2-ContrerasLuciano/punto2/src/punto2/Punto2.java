package punto2;
import java.util.Scanner;

public class Punto2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.print("Ingrese el primer número: ");
        int num1 = scan.nextInt();

        System.out.print("Ingrese el segundo número: ");
        int num2 = scan.nextInt();

        System.out.print("Ingrese el tercer número: ");
        int num3 = scan.nextInt();

        int mayor = Math.max(num1, Math.max(num2, num3));

        System.out.println("El número mayor es: " + mayor);
    }
}
